If you are on windows click on start.bat and wait

password : gHZSoh5mPZUXtpkjmu5Q



Or

If you are on Mac or Windows double click on plist-cropper-merger-03-2018.jar and enter 

password: gHZSoh5mPZUXtpkjmu5Q

 

